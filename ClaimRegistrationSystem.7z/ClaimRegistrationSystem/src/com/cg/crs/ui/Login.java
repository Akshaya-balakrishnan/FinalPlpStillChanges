package com.cg.crs.ui;

import java.util.Scanner;

import com.cg.crs.exception.CRSException;
import com.cg.crs.mainclasses.Admin;
import com.cg.crs.mainclasses.Claim;
import com.cg.crs.model.UserRole;
import com.cg.crs.service.CRSService;
import com.cg.crs.service.implementation.CRSServiceImpl;

public class Login {

	public static void main(String[] args) {
		Scanner scanner = null;
		CRSService crsService = new CRSServiceImpl();
		boolean flag1 = false;
		do {

			System.out.println("******** -Insurance Claiming **********");
			scanner = new Scanner(System.in);
			System.out.println("enter username");
			String userName = scanner.nextLine();
			System.out.println("Enter password");
			String password = scanner.nextLine();
			UserRole user = new UserRole();
			user.setUserName(userName);
			user.setPassword(password);
			boolean services;
			try {
				services = crsService.validateFields(user);
				if (services == true) {
					switch (user.getRoleCode()) {
					case "INSURED":
						Claim.claimCreation(user);
						flag1 = true;
						break;
					case "AGENT":
						Claim.claimCreation(user);
						flag1 = true;
						break;
					case "ADMIN":
						Admin.adminClient(user);
						flag1 = true;
						break;
					default:
						break;
					}

				} else {

					System.out.println("Enter Valid Username/Password");
					flag1 = false;
				}
			} catch (CRSException e) {
				flag1 = false;
				System.err.println(" " + e.getMessage());
			}

		} while (!flag1);
		scanner.close();
	}
}
package com.cg.crs.mainclasses;

import java.util.Scanner;

import com.cg.crs.exception.CRSException;
import com.cg.crs.model.UserRole;
import com.cg.crs.service.CRSService;
import com.cg.crs.service.implementation.CRSServiceImpl;

public class Login {

	public static void main(String[] args) {
		Scanner scanner = null;
		CRSService crsService = new CRSServiceImpl();
		System.out.println("* * * * * * * * Insurance Claiming * * * * * * * *");
		boolean flag1 = false;
		do {

			
			scanner = new Scanner(System.in);
			System.out.println("Enter Username:");
			String userName = scanner.nextLine();
			System.out.println("Enter Password:");
			String password = scanner.nextLine();
			UserRole user = new UserRole();
			user.setUserName(userName);
			user.setPassword(password);
			boolean services;
			try {
				services = crsService.validateFields(user);
				if (services == true) {
					switch (user.getRoleCode()) {
					case "INSURED":
						System.out.println(" ");
						System.out.println("========================Insured Role===============================");
						System.out.println("                        Welcome User");
						Claim.claimCreation(user);
						flag1 = true;
						break;
					case "AGENT":
						System.out.println(" ");
						System.out.println("===========================Agent===================================");
						System.out.println("                        Welcome Agent");
						Claim.claimCreation(user);
						flag1 = true;
						break;
					case "ADMIN":
						System.out.println(" ");
						System.out.println("=========================Admin Role ===============================");
						System.out.println("                        Welcome Admin");
						Admin.adminClient(user);
						flag1 = true;
						break;
					default:
						break;
					}

				} else {

					System.out.println("Enter Valid Username/Password");
					flag1 = false;
				}
			} catch (CRSException e) {
				flag1 = false;
				System.err.println(" " + e.getMessage());
			}

		} while (!flag1);
		scanner.close();
	}
}
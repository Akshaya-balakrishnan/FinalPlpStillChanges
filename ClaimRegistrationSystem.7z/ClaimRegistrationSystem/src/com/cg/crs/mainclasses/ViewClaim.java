package com.cg.crs.mainclasses;

import java.util.List;
import java.util.Scanner;

import com.cg.crs.exception.CRSException;
import com.cg.crs.model.ClaimCreationEntity;
import com.cg.crs.model.UserRole;
import com.cg.crs.service.CRSService;
import com.cg.crs.service.implementation.CRSServiceImpl;

public class ViewClaim {
	public static void viewClaim(UserRole user) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Policy Number for viewing Claim Status");
		long claimPolicyNo = scanner.nextLong();
		CRSService service = new CRSServiceImpl();
		List<ClaimCreationEntity> list2;
		try {
			list2 = service.viewClaimStatus(claimPolicyNo);
			System.out.println("Your Claims");
			for (ClaimCreationEntity entity : list2) {
				System.out.println("\nClaim Number:    " + entity.getClaimNumber() + "\nClaim Reason:    "
						+ entity.getClaimReason() + "\nAccident Street: " + entity.getAccidentLocationStreet()
						+ "\nAccident City:   " + entity.getAccidentCity() + "\nAccident State   "
						+ entity.getAccidentState() + "\nAccident Zip     " + entity.getAccidentZip()
						+ "\nClaim Type       " + entity.getClaimType() + "\nYour Claim is Approved ");
			}
		} catch (CRSException e) {
			System.err.println("Problem Occured while Viewing Claim Status");
		}
		scanner.close();
	}
}
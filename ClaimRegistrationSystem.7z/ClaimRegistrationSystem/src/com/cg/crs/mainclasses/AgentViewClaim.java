package com.cg.crs.mainclasses;

import java.util.List;

import com.cg.crs.exception.CRSException;
import com.cg.crs.model.AgentClaim;
import com.cg.crs.model.UserRole;
import com.cg.crs.service.CRSService;
import com.cg.crs.service.implementation.CRSServiceImpl;

public class AgentViewClaim {
	public static void agentViewClaim(UserRole user) {
		String userName = user.getUserName();
		System.out.println("Your Customer's Claiming History are");
		CRSService service = new CRSServiceImpl();
		service = new CRSServiceImpl();
		List<AgentClaim> list2;
		try {
			list2 = service.claimData(userName);
			System.out.println("list ");
			for (AgentClaim list3 : list2) {
				System.out.println(list3.getAgentClaimNumber() + "             " + list3.getAgentClaimReason()
						+ "           " + list3.getAgentAccidentLocationStreet() + "           "
						+ list3.getAgentAccidentCity() + "           " + list3.getAgentAccidentState() + "           "
						+ list3.getAgentAccidentZip() + "    " + list3.getAgentClaimType() + "       "
						+ list3.getAgentPolicyNumber());
			}
		} catch (CRSException e) {

			System.err.println("Problem Occured while viewing customer claim status ");
		}

	}

}
